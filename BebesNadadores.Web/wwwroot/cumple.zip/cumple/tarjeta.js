(() => {
  'use strict';
  const confetti = document.getElementById('confetti');
  const celebrateBtn = document.getElementById('celebrateBtn');
  const musicBtn = document.getElementById('musicBtn');
  const audio = document.getElementById('birthdayAudio');
  const colors = ['#78dff7','#ffe3a0','#f6a7d6','#ffffff','#31bad9','#b0ffed'];
  function celebrate() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const fragment = document.createDocumentFragment();
    for (let i = 0; i < 75; i++) {
      const piece = document.createElement('span');
      piece.className = 'confetti-piece';
      piece.style.setProperty('--left', `${Math.random() * 100}%`);
      piece.style.setProperty('--delay', `${Math.random() * 1.25}s`);
      piece.style.setProperty('--duration', `${2.5 + Math.random() * 2}s`);
      piece.style.setProperty('--rotate', `${Math.random() * 360}deg`);
      piece.style.setProperty('--color', colors[i % colors.length]);
      piece.addEventListener('animationend', () => piece.remove(), { once:true });
      fragment.appendChild(piece);
    }
    confetti.appendChild(fragment);
  }
  celebrateBtn?.addEventListener('click', celebrate);
  // El botón de audio solo se muestra si está subido el archivo MP3.
  if (document.body.dataset.hayMusica === 'true' && musicBtn && audio) {
    musicBtn.hidden = false;
    musicBtn.addEventListener('click', async () => {
      if (!audio.paused) {
        audio.pause();
        musicBtn.textContent = '♫ Activar música';
        musicBtn.setAttribute('aria-pressed','false');
      } else {
        try {
          await audio.play();
          musicBtn.textContent = '♫ Pausar música';
          musicBtn.setAttribute('aria-pressed','true');
        } catch {
          musicBtn.textContent = 'No se pudo reproducir la música';
        }
      }
    });
  }
  document.addEventListener('DOMContentLoaded', () => setTimeout(celebrate, 400), { once:true });
})();
